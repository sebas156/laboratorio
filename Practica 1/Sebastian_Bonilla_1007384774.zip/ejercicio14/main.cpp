#include <iostream>

using namespace std;

int main()
{
    int mayor=50;
    for (int menor=1;menor<=50;menor++) {
        cout<<menor<<"   "<<mayor<<endl;
        mayor--;
    }
    return 0;
}
